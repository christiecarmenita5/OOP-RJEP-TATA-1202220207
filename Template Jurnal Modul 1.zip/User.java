public class User {

    // TODO: Create Private Attribute of User (Name and Phone Number) then Create Setter method for each attribute



    // TODO: Create Method to Register User and Display User's Name and Phone Number and success message

}
