import java.util.List;
import java.util.ArrayList;

public class Database {

    // TODO: Create List of Konser Object to Store Konser from Konser Class


    // TODO: Create Method to insert Konser to Database


    // TODO: Create Method to Show Konser from Database


    // TODO: Create Method to Buy Ticket and Show the Total Price

}
