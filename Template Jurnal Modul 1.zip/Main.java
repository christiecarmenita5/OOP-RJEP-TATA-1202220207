import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        // TODO: Create Database Object


        // TODO: Create Konser Object and Set the Attributes


        // TODO: Insert Konser Object to Database


        // TODO: Display Greeting Message and Prompt User to Register


        // TODO: Create a User Object and Set the Attributes


        // TODO: Display Main Menu and Prompt User to Choose Menu
        
    }
}
